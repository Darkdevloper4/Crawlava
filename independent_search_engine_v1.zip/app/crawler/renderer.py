from playwright.async_api import async_playwright
from app.config import PLAYWRIGHT_HEADLESS

async def render_page(url):
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=PLAYWRIGHT_HEADLESS)
        page = await browser.new_page()
        await page.goto(url, timeout=30000)
        content = await page.content()
        await browser.close()
        return content
