import asyncio

class URLFrontier:
    def __init__(self):
        self.queue = asyncio.Queue()
        self.seen = set()

    async def add_url(self, url):
        if url not in self.seen:
            self.seen.add(url)
            await self.queue.put(url)

    async def get_url(self):
        return await self.queue.get()

    def task_done(self):
        self.queue.task_done()
