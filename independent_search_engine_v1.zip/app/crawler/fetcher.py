import aiohttp
from app.config import USER_AGENT, REQUEST_TIMEOUT

async def fetch(url):
    headers = {"User-Agent": USER_AGENT}
    timeout = aiohttp.ClientTimeout(total=REQUEST_TIMEOUT)

    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.get(url, headers=headers) as response:
            html = await response.text()
            return response.status, html
