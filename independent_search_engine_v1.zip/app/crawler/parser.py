from bs4 import BeautifulSoup
from urllib.parse import urljoin

def parse(html, base_url):
    soup = BeautifulSoup(html, "html.parser")
    title = soup.title.string if soup.title else ""
    text = soup.get_text(separator=" ", strip=True)

    links = []
    for a in soup.find_all("a", href=True):
        links.append(urljoin(base_url, a["href"]))

    images = []
    for img in soup.find_all("img", src=True):
        images.append(urljoin(base_url, img["src"]))

    return {
        "title": title,
        "text": text,
        "links": links,
        "images": images
    }
