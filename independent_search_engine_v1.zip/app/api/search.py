from fastapi import APIRouter
from app.indexer.tokenizer import tokenize

router = APIRouter()

@router.get("/search")
async def search(q: str):
    tokens = tokenize(q)

    results = []
    for token in tokens:
        results.append({
            "title": f"Result for {token}",
            "url": f"https://example.com/{token}"
        })

    return {"results": results}
