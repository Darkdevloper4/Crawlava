import re

STOPWORDS = set(["the","is","and","of","to","in"])

def tokenize(text):
    words = re.findall(r"\w+", text.lower())
    return [w for w in words if w not in STOPWORDS]
