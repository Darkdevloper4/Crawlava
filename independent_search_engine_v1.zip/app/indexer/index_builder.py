from collections import defaultdict
from app.indexer.tokenizer import tokenize

def build_inverted_index(text):
    tokens = tokenize(text)
    index = defaultdict(int)

    for word in tokens:
        index[word] += 1

    return dict(index)
